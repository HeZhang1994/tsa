# Time Series Analysis for Researchers
> GW4 introductory workshop for Time Series Analysis to doctoral candidates

* Instructor **[Dr Herrera](https://scholar.google.co.uk/citations?user=Q2Vv-0AAAAAJ)**.
* Content: Dr Herrera and Daniel Fosas.
* Acknowledgements: Special thanks to
  - **[Prof Eamonn Keogh](https://www.cs.ucr.edu/~eamonn/)**, 
    *University of California, Riverside - US*, 
    for his inspirational work and for sharing part of the material introduced in these notes.
  - The outstanding Python community behind the libraries that power our analyses.


## Requirements

The project works with the [Anaconda Python distribution](https://www.anaconda.com/distribution/#download-section).

The project depends on having their `conda` package manager to
handle all the requirements in a standalone Python environment.
All requirements are listed in the file `conda-tsar.yaml`.


## Installation

[Download or clone](https://help.github.com/en/articles/cloning-a-repository) this repository.

Execute the following in a shell that has `conda` in its path.

```sh
conda env create -f conda-tsar.yaml
```

Other recommended optional packages:
```sh
jupyter labextension install @jupyterlab/toc
```

## Start

Execute the following in a shell that has `conda` in its path 
from the project folder

```sh
conda activate tsar
jupyter lab
```

Then do some science 😃.


## Uninstall

```sh
conda activate base
conda remove --name tsar --all
```


## Meta

<a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-nc-sa/4.0/88x31.png" /></a>

This work is licensed under a 
<a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/">Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License</a>.

This workshop was possible thanks to the generous support of the [GW4 Alliance](http://gw4.ac.uk/).
