# -*- coding: utf-8 -*-
"""Compare two numeric signals.

Author: Daniel Fosas
"""

from typing import Dict, NamedTuple, Optional, Union

import numpy as np
import pandas as pd


Num = Union[int, float, np.ndarray]


class Entry(NamedTuple):
    value: Union[float, np.ndarray]
    unit: str


def _sum_sq(x):
    return np.sum(np.square(x))


def report(a: np.ndarray, b: np.ndarray, unit: Optional[str] = None):
    """Calculate several goodness-of-fit metrics, optionally reporting units.

    Conventions as per ASHRAE Guideline 14: :math:`(a - b) / a`.

    Parameters
    ----------
    a
        First vector (measured values in ASHRAE Guideline 14).
    b
        Second vector (modelled values in ASHRAE Guideline 14).
    unit
        Original units of measurements for `a` and `b`.

    Returns
    -------
    pd.DataFrame

    Examples
    --------
    Ideal solutions (if `a == b`):
    >>> a = np.arange(1, 10)
    >>> report(a=a, b=a, unit='°C')
                                value unit
    total bias                    0.0   °C
    total error                   0.0   °C
    mean bias                     0.0   °C
    mean bias error               0.0    -
    mean normalized error         0.0    -
    normalized mean bias error    0.0    -
    root mean squared error       0.0   °C
    cv rmse                       0.0    -
    rsquared                      1.0    -
    index_of_agreement            1.0    -

    """
    unit = '' if unit is None else unit
    r = {
        'total bias':
            Entry(value=total_bias(a=a, b=b), unit=unit),
        'total error':
            Entry(value=total_error(a=a, b=b), unit=unit),
        'mean bias':
            Entry(value=mean_bias(a=a, b=b), unit=unit),
        'mean bias error':
            Entry(value=mean_bias_error(a=a, b=b), unit='-'),
        'mean normalized error':
            Entry(value=mean_normalized_error(a=a, b=b), unit='-'),
        'normalized mean bias error':
            Entry(value=normalized_mean_bias_error(a=a, b=b), unit='-'),
        'root mean squared error':
            Entry(value=root_mean_squared_error(a=a, b=b), unit=unit),
        'cv rmse':
            Entry(value=cv_rmse(a=a, b=b), unit='-'),
        'rsquared':
            Entry(value=rsquared(a=a, b=b), unit='-'),
        'index_of_agreement':
            Entry(value=index_of_agreement(a=a, b=b), unit='-')
    }
    return pd.DataFrame.from_dict(r, orient='index')


def report_units() -> Dict[str, str]:
    """Return report dictionary with [model, unit].

    Examples
    --------
    >>> for k, v in sorted(report_units().items()):
    ...     print(f'{k:30} --> {v}')
    cv rmse                        --> -
    index_of_agreement             --> -
    mean bias                      --> original
    mean bias error                --> -
    mean normalized error          --> -
    normalized mean bias error     --> -
    root mean squared error        --> original
    rsquared                       --> -
    total bias                     --> original
    total error                    --> original

    """
    a = b = np.arange(1, 5)
    return report(a=a, b=b, unit='original')['unit'].to_dict()


def total_bias(a: Num, b: Num):
    """Total bias.

    Formula:

    .. math::

        value = \\sum\\limits_{i=1}^{n} a_i - b_i

    Examples
    --------

    >>> a = np.linspace(start=-3, stop=3, num=7)
    >>> total_bias(a=a, b=(a + 0.5))
    -3.5
    >>> total_bias(a=a, b=(a - 0.5))
    3.5
    >>> total_bias(a=a, b=a)
    0.0

    """
    return np.sum(a - b)


def total_error(a: Num, b: Num):
    """Total Error.

    Formula:

    .. math::

        value = \\sum\\limits_{i=1}^{n} |a_i - b_i|

    Examples
    --------

    >>> a = np.linspace(start=-3, stop=3, num=7)
    >>> total_error(a=a, b=(a + 0.5))
    3.5
    >>> total_error(a=a, b=(a - 0.5))
    3.5
    >>> total_error(a=a, b=a)
    0.0

    """
    return np.sum(np.abs(a - b))


def mean_bias(a: Num, b: Num):
    """ Mean Bias.

    Formula:

    .. math::

        value = \\frac{1}{n} \\sum\\limits_{i=1}^{n} a_i - b_i

    Examples
    --------

    >>> a = np.linspace(start=-3, stop=3, num=7)
    >>> mean_bias(a=a, b=(a + 0.5))
    -0.5
    >>> mean_bias(a=a, b=(a - 0.5))
    0.5
    >>> mean_bias(a=a, b=a)
    0.0

    """
    return np.mean(a - b)


def mean_bias_error(a: Num, b: Num):
    """ Mean Bias Error.

    Formula:

    .. math::

        value = \\frac{\\sum\\limits_{i=1}^{n} a_i - b_i}
                      {\\sum\\limits_{i=1}^{n} a_i}

    Examples
    --------

    >>> a = np.linspace(start=0, stop=6, num=7)
    >>> print(round(mean_bias_error(a=a, b=0.8 * a), 2))
    0.2
    >>> print(round(mean_bias_error(a=a, b=1.2 * a), 2))
    -0.2
    >>> print(round(mean_bias_error(a=a, b=a), 2))
    0.0

    """
    return np.sum(a - b) / np.sum(a)


def mean_normalized_error(a: Num, b: Num):
    """Mean normalized error.

    Formula:

    .. math::

        value = \\frac{1}{n} \\sum\\limits_{i=1}^{n} \\frac{a_i - b_i}{a_i}

    Examples
    --------

    >>> a = np.linspace(start=-3.5, stop=2.5, num=7)
    >>> print(round(mean_normalized_error(a=a, b=1.7 * a), 10))
    -0.1
    >>> print(round(mean_normalized_error(a=a, b=a), 10))
    0.0
    >>> a = np.linspace(start=-2.5, stop=3.5, num=7)
    >>> print(round(mean_normalized_error(a=a, b=1.7 * a), 10))
    0.1
    >>> print(round(mean_normalized_error(a=a, b=a), 10))
    0.0

    """
    return np.mean(np.abs(a - b) / a)


def normalized_mean_bias_error(a: Num, b: Num):
    """Normalized mean bias error.

    Formula:

    .. math::

        value = \\frac{\\frac{1}{n} \\sum\\limits_{i=1}^{n} a_i - b_i}
                      {\\overline{a}}

    Examples
    --------

    >>> a = np.linspace(start=-2.5, stop=3.5, num=7)
    >>> print(round(normalized_mean_bias_error(a=a, b=0.7 * a), 10))
    0.3
    >>> print(round(normalized_mean_bias_error(a=a, b=a), 10))
    0.0
    >>> a = np.linspace(start=-2.5, stop=3.5, num=7)
    >>> print(round(normalized_mean_bias_error(a=a, b=1.7 * a), 10))
    -0.7
    >>> print(round(normalized_mean_bias_error(a=a, b=a), 10))
    0.0

    """
    return np.mean(a - b) / np.mean(a)


def root_mean_squared_error(a: Num, b: Num):
    """Root mean squared error.

    Formula:

    .. math::

        value = \\sqrt{\\frac{1}{n} \\sum\\limits_{i=1}^{n} (a_i - b_i)^2}

    Examples
    --------

    >>> a = np.linspace(start=0, stop=7, num=7)
    >>> print(round(root_mean_squared_error(a=a, b=(a + 10)), 10))
    10.0
    >>> print(round(root_mean_squared_error(a=-a, b=(10 - a)), 10))
    10.0
    >>> print(round(root_mean_squared_error(a=a, b=a), 10))
    0.0

    """
    return np.sqrt(np.mean(np.square(a - b)))


def cv_rmse(a: Num, b: Num):
    """Coefficient of variation of the root mean squared error.

    Formula:

    .. math::

        value = \\frac
            {\\sqrt{\\frac{1}{n} \\sum\\limits_{i=1}^{n} (a_i - b_i)^2}}
            {\\overline{a}}

    Examples
    --------

    >>> a = np.linspace(start=1, stop=9, num=9)
    >>> print(round(cv_rmse(a=a, b=(a + 10)), 10))
    2.0
    >>> print(round(cv_rmse(a=-a, b=(10 - a)), 10))
    -2.0
    >>> print(round(cv_rmse(a=a, b=a), 10))
    0.0

    """
    return root_mean_squared_error(a=a, b=b) / np.mean(a)


def rsquared(a: Num, b: Num):
    """R-squared.

    Formula:

    .. math::

        value = 1 - \\frac{\\sum\\limits_{i=1}^{n} (a_i - b_i)^2}
                          {\\sum\\limits_{i=1}^{n} (a_i - \\overline{a})^2}

    Examples
    --------

    >>> a = np.linspace(start=0, stop=6, num=7)
    >>> print(round(rsquared(a=a, b=(a + 1)), 10))
    0.75
    >>> print(round(rsquared(a=a, b=(a + 10)), 10))
    -24.0
    >>> print(round(rsquared(a=a, b=a), 10))
    1.0

    """
    mean = np.mean(a)
    return 1 - _sum_sq(a - b) / _sum_sq(a - mean)


def index_of_agreement(a: Num, b: Num):
    """Index of agreement.

    Formula:

    .. math::

        value = 1 - \\frac{\\sum\\limits_{i=1}^{n} (a_i - b_i)^2}
                          {\\sum\\limits_{i=1}^{n}
                          (|b_i - \\overline{a}| + |a_i - \\overline{a}|)^2}

    Examples
    --------

    >>> a = np.linspace(start=0, stop=6, num=7)
    >>> print(round(index_of_agreement(a=a, b=(a + 1)), 10))
    0.9411764706
    >>> print(round(index_of_agreement(a=a, b=(a + 10)), 10))
    0.297188755
    >>> print(round(index_of_agreement(a=a, b=a), 10))
    1.0

    """
    return 1 - (_sum_sq(a - b) /
                _sum_sq(np.abs(b - np.mean(a)) + np.abs(a - np.mean(a))))
