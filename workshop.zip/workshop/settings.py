# Pandas
pd.set_option('display.max_rows',    10)
pd.set_option('display.max_columns', 10)

# Matplotlib
plt.style.use('seaborn-whitegrid')
plt.rcParams.update({'font.size': 16,
                     'figure.figsize': (10, 5)})
